// S/W Environment : AVR Studio + WINAVR Compiler
// Target : M128
// Crystal: 16Mhz
//
// Author: chowk.
// 

// 4 by 3 Keypad�� ���� Key ���� �д´�.
// Key Scan Output Port : PORTC(PC4 - PC7)
// Key Input Port : PORTE(PE4 - PE7)
// Debouncing : delay_10uSec(unsigned int time_10us) �Լ��� �̿� �Ѵ�.

// ���α׷� ����
//   �͹̳� ���α׷�(OC Console ��)�� ��� ��ġ�� �̿� �ϰ�,
//   Keypad�� key�� �Է� ��ġ�� ��� �Ѵ�. 


#  ifndef atmega128
	#define atmega128
#  endif
#define FOSC 16000000// Clock Speed

#include <avr/io.h>
#include <avr/interrupt.h>

//#include "C:/WinAVR/avr/include/avr/iom128.h"
#include <stdio.h>

#include "cho_uart0_init.h"
#include "get_keypad.h"

void InitDevices(void);
static int put_char(char c, FILE *stream);

//volatile unsigned int cnt = 0;


static int put_char(char c, FILE *stream)
{
	tx0_char(c);
	return 0; 
}

//call this routine to initialize all peripherals
void Init_devices(void)
{
	//stop errant interrupts until set up
	cli();         //disable all interrupts
	keypad_init();   // I/O Port, timer3 init
	uart0_init(); // UART 0 �ʱ�ȭ
	fdevopen(put_char,0);   
	sei();         //re-enable interrupts
	 //all peripherals are now initialized
}



int main (void)
{
	unsigned char keyData;

	Init_devices();
	
	printf("\n\rKeyPad Input Testing \n\r");

	// Infinite loop
	while(1){
		keyData = get_key( );
//		printf("Char : %c  KeyData : %x \r\n",keyData,keyData);
		putchar(keyData);
	}
	return 0;
}
