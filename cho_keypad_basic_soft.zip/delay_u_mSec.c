// S/W Environment : AVR Studio + WINAVR Compiler
// Target : M128
// Crystal: 16Mhz
//
// Author: chowk.

// Software Delay Function

void delay_1mSec(unsigned int time_ms);
void delay_1uSec(unsigned char time_us);

// mSec ������ Time  Delay�� ���� �Լ�
// �ִ� Delay Time : 65536mSec
void delay_1mSec(unsigned int time_ms){

    unsigned int i;
	
	// 1cycle = 1/16000000 -> 0.0625uSec
	// one loop takes 1mSec 
    for(i = 0; i < time_ms; i++)
    { 
      delay_1uSec(250);
      delay_1uSec(250);
      delay_1uSec(250);
      delay_1uSec(250);
    }

}

// uSec ������ Time  Delay�� ���� �Լ�
// �ִ� Delay Time : 256uSec
// 1cycle = 1/16000000 -> 0.0625uSec
void delay_1uSec(unsigned char time_us){    // time delay(us)

    register unsigned char i;
    for(i = 0; i < time_us; i++)  // 4 cycle +
    { 
      asm volatile(" PUSH  R0 ");       // 2 cycle +
      asm volatile(" POP   R0 ");       // 2 cycle +
      asm volatile(" PUSH  R0 ");       // 2 cycle +
      asm volatile(" POP   R0 ");       // 2 cycle +
      asm volatile(" PUSH  R0 ");       // 2 cycle +
      asm volatile(" POP   R0 ");       // 2 cycle = 16 cycle * 0.0625uSec = 1uSec for 16MHz
    }
}
