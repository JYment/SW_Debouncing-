void delay_1mSec(unsigned int time_ms);
void delay_1uSec(unsigned char time_us);
