void keypad_init(void);  // I/O Port, timer3 init
unsigned char get_key( void );
