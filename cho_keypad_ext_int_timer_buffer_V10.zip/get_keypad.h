#define ROW_MASK 0xf0
#define COL_MASK 0x70

#define FALLING_EDGE 0x2a
#define RISING_EDGE 0x3f

void keypad_init(void);  // I/O Port, timer3 init
char key_scan(void);
