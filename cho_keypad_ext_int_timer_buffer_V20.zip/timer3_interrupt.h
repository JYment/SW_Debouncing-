void timer_init(void);
